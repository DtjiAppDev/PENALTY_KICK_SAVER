# Penalty Kick Saver

A Python package which is used to play a game of saving a penalty kick.

## Usage

Typing the direction where the goalkeeper goes will output whether the
penalty kick is successfully saved or not.